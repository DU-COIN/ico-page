export const SERVER_URL = 'http://localhost:5000' 
// export const SERVER_URL = 'https://zepcash.io'
// export const BASE_FILE_PATH = 'https://zepcash.io/zepxasset'

