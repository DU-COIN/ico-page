export const RpcUrl = " https://bsc-dataseed.binance.org/";
export const Ducoin_Address = "0x50A0110c131c3b3C5a3BE9d2c965cE3319249A97";
export const Ico_Address = "0xF6f20Fa9721e626a5b0148a015919E31521Ee1De";
export const Usdt_Address = "0x55d398326f99059fF775485246999027B3197955";
export const Busd_Address = "0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56";
export const Du_coin = require("../contract/Ducoin.json");
export const Ico_Abi = require("../contract/ico-abi.json");
export const Coin_Abi = require("../contract/coin.json");
